<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<center>

<form id = "cadastro" action = "cadastro.php" method = "POST">
    nome: <input type = "text" name = "nome" required><br>
    login: <input type = "text" name = "login" required><br>
    senha: <input type = "pasword" name = "senha" required><br><br>
    <input type = "submit" id = "cadastrar" value = "cadastrar">

</center>
</body>
</html>